import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-search-countries',
  templateUrl: './search-countries.component.html',
  styleUrls: ['./search-countries.component.css']
})
export class SearchCountriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
